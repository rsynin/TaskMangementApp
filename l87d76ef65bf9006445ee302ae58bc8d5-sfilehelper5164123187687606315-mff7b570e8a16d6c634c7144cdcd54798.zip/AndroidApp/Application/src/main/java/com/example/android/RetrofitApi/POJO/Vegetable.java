package com.example.android.RetrofitApi.POJO;

public class Vegetable {
    public String name;
    public String plantTime;
    public String harvestTime;

    public Vegetable(String name, String plantTime, String harvestTime) {
        this.name = name;
        this.plantTime = plantTime;
        this.harvestTime = harvestTime;
    }
}
