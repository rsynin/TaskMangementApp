package com.example.android.RetrofitApi.POJO;

public class TaskPatch {
    public String usrName;
    public String taskName;

    public TaskPatch(String usrName, String taskName) {
        this.usrName = usrName;
        this.taskName = taskName;
    }
}
